import { BrowserRouter, Routes, Route } from 'react-router'
import './App.css'
import SignInPage from './Pages/Auth/SignInPage';
import LoginPage from './Pages/Auth/LoginPage';
import Home from './Pages/Home';
import ProtectedRoutes from './Context/ProtectedRoutes.jsx';
import Article from './Pages/Article.jsx';
import { AuthProvider } from './Context/auth.context';
import Layout from './Components/Layout';
import AddArticleForm from './Components/AddArticle.jsx';
import Stats from './Pages/Stats.jsx';

function App() {
  return (
    <div>
    <AuthProvider>
      <BrowserRouter>
        <Routes>
         <Route element={<Layout />}>
            <Route element={<ProtectedRoutes />}>
                <Route path="/post/new" element={<AddArticleForm />} />
                 <Route path="/stats" element={<Stats />} />
            </Route>
          
            <Route index path="/home" element={<Home />} />
            <Route path="/post/:id" element={<Article />} />

            <Route path='/sign-up' element={<SignInPage />}/>
            <Route path='/login' element={<LoginPage />}/>
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
    </div>
  )
}

export default App
